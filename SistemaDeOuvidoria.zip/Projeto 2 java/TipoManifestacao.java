public enum TipoManifestacao {
    SUGESTAO, ELOGIO, CRITICA;
}
