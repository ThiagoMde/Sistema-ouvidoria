public interface Auditavel {
    String recuperarAutor();
    String recuperarDataCriacao();
}
