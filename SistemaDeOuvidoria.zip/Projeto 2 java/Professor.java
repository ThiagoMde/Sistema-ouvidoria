public class Professor extends Usuario {
    private int cargaHoraria;

    public Professor(String nome, String telefone, String dataNascimento, int cargaHoraria) {
        super(nome, telefone, dataNascimento);
        this.cargaHoraria = cargaHoraria;
    }

    @Override
    public String recuperarAutor() {
        return getNome();
    }

    @Override
    public String recuperarDataCriacao() {
        return dataNascimento;
    }

    @Override
    public String toString() {
        return super.toString() + ", Carga Horária: " + cargaHoraria + "h";
    }
}
