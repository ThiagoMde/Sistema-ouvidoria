import javax.swing.JOptionPane;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class SistemaOuvidoria {
    private List<Usuario> usuarios;
    private List<Manifestacao> manifestacoes;

    public SistemaOuvidoria() {
        usuarios = new ArrayList<>();
        manifestacoes = new ArrayList<>();
    }

    public void adicionarUsuario(Usuario usuario) {
        usuarios.add(usuario);
    }

    public void adicionarManifestacao(Manifestacao manifestacao) {
        manifestacoes.add(manifestacao);
    }

    public void listarTodosUsuarios() {
        StringBuilder sb = new StringBuilder();
        for (Usuario usuario : usuarios) {
            sb.append(usuario).append("\n");
        }
        JOptionPane.showMessageDialog(null, sb.toString());
    }

    public void listarManifestacoes() {
        StringBuilder sb = new StringBuilder();
        for (Manifestacao manifestacao : manifestacoes) {
            sb.append(manifestacao).append("\n");
        }
        JOptionPane.showMessageDialog(null, sb.toString());
    }

    public void listarManifestacaoPorPosicao(int posicao) {
        if (posicao < 0 || posicao >= manifestacoes.size()) {
            JOptionPane.showMessageDialog(null, "Posição inválida!");
        } else {
            Manifestacao m = manifestacoes.get(posicao);
            JOptionPane.showMessageDialog(null, m.toString());
        }
    }

    public void exibirMenu() {
        boolean rodando = true;
        while (rodando) {
            String opcao = JOptionPane.showInputDialog(null,
                "Escolha uma opção:\n" +
                "1 - Cadastrar Usuário\n" +
                "2 - Cadastrar Manifestação\n" +
                "3 - Listar Todos os Usuários\n" +
                "4 - Listar Todas as Manifestações\n" +
                "5 - Listar Manifestação por Posição\n" +
                "6 - Sair");

            switch (opcao) {
                case "1":
                    cadastrarUsuario();
                    break;
                case "2":
                    cadastrarManifestacao();
                    break;
                case "3":
                    listarTodosUsuarios();
                    break;
                case "4":
                    listarManifestacoes();
                    break;
                case "5":
                    String pos = JOptionPane.showInputDialog("Digite a posição da manifestação:");
                    int posicao = Integer.parseInt(pos);
                    listarManifestacaoPorPosicao(posicao);
                    break;
                case "6":
                    JOptionPane.showMessageDialog(null, "Total de usuários cadastrados: " + usuarios.size());
                    JOptionPane.showMessageDialog(null, "Total de manifestações cadastradas: " + manifestacoes.size());
                    rodando = false;
                    break;
                default:
                    JOptionPane.showMessageDialog(null, "Opção Inválida");
                    break;
            }
        }
    }

    private void cadastrarUsuario() {
        String tipo = JOptionPane.showInputDialog("Tipo de usuário (Aluno, Professor, Colaborador):");
        String nome = JOptionPane.showInputDialog("Nome:");
        String telefone = JOptionPane.showInputDialog("Telefone:");
        String dataNascimento = JOptionPane.showInputDialog("Data de Nascimento:");
        switch (tipo.toLowerCase()) {
            case "aluno":
                double media = Double.parseDouble(JOptionPane.showInputDialog("Média:"));
                Aluno aluno = new Aluno(nome, telefone, dataNascimento, media);
                adicionarUsuario(aluno);
                break;
            case "professor":
                int cargaHoraria = Integer.parseInt(JOptionPane.showInputDialog("Carga Horária:"));
                Professor professor = new Professor(nome, telefone, dataNascimento, cargaHoraria);
                adicionarUsuario(professor);
                break;
            case "colaborador":
                String setor = JOptionPane.showInputDialog("Setor:");
                Colaborador colaborador = new Colaborador(nome, telefone, dataNascimento, setor);
                adicionarUsuario(colaborador);
                break;
            default:
                JOptionPane.showMessageDialog(null, "Tipo de usuário não reconhecido!");
                break;
        }
    }

    private void cadastrarManifestacao() {
        if (usuarios.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Nenhum usuário cadastrado! Cadastre um usuário primeiro.");
            return;
        }

        String descricao = JOptionPane.showInputDialog("Descrição da Manifestação:");
        LocalDate dataManifestacao = LocalDate.parse(JOptionPane.showInputDialog("Data da Manifestação (AAAA-MM-DD):"));
        String nomeUsuario = JOptionPane.showInputDialog("Nome do Usuário:");
        Usuario usuario = usuarios.stream()
            .filter(u -> u.getNome().equalsIgnoreCase(nomeUsuario))
            .findFirst()
            .orElse(null);

        if (usuario == null) {
            JOptionPane.showMessageDialog(null, "Usuário não encontrado!");
            return;
        }

        String tipo = JOptionPane.showInputDialog("Tipo da Manifestação (SUGESTAO, ELOGIO, CRITICA):");
        TipoManifestacao tipoManifestacao = TipoManifestacao.valueOf(tipo.toUpperCase());
        
        Manifestacao manifestacao = new Manifestacao(descricao, dataManifestacao, usuario, tipoManifestacao);
        adicionarManifestacao(manifestacao);
    }

    public static void main(String[] args) {
        SistemaOuvidoria sistema = new SistemaOuvidoria();
        sistema.exibirMenu();
    }
}
