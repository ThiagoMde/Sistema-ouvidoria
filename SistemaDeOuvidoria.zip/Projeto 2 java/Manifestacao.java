import java.time.LocalDate;

public class Manifestacao implements Auditavel {
    private String descricao;
    private LocalDate dataManifestacao;
    private Usuario usuario;
    private TipoManifestacao tipo;

    public Manifestacao(String descricao, LocalDate dataManifestacao, Usuario usuario, TipoManifestacao tipo) {
        this.descricao = descricao;
        this.dataManifestacao = dataManifestacao;
        this.usuario = usuario;
        this.tipo = tipo;
    }

    @Override
    public String recuperarAutor() {
        return usuario.getNome();
    }

    @Override
    public String recuperarDataCriacao() {
        return dataManifestacao.toString();
    }

    @Override
    public String toString() {
        return "Descrição: " + descricao + ", Data: " + dataManifestacao + ", Usuário: " + usuario.getNome() + ", Tipo: " + tipo;
    }
}
