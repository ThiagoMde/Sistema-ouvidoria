public class Aluno extends Usuario {
    private double media;

    public Aluno(String nome, String telefone, String dataNascimento, double media) {
        super(nome, telefone, dataNascimento);
        this.media = media;
    }

    @Override
    public String recuperarAutor() {
        return getNome();
    }

    @Override
    public String recuperarDataCriacao() {
        return dataNascimento;  // Assume-se que a data de nascimento é usada aqui para simplificar.
    }

    @Override
    public String toString() {
        return super.toString() + ", Média: " + media;
    }
}
