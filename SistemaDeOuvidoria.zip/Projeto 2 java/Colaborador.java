public class Colaborador extends Usuario {
    private String setor;

    public Colaborador(String nome, String telefone, String dataNascimento, String setor) {
        super(nome, telefone, dataNascimento);
        this.setor = setor;
    }

    @Override
    public String recuperarAutor() {
        return getNome();
    }

    @Override
    public String recuperarDataCriacao() {
        return dataNascimento;
    }

    @Override
    public String toString() {
        return super.toString() + ", Setor: " + setor;
    }
}
