public abstract class Usuario implements Auditavel {
    protected String nome;
    protected String telefone;
    protected String dataNascimento;

    public Usuario(String nome, String telefone, String dataNascimento) {
        this.nome = nome;
        this.telefone = telefone;
        this.dataNascimento = dataNascimento;
    }

    public String getNome() {
        return nome;
    }

    @Override
    public String toString() {
        return "Nome: " + nome + ", Telefone: " + telefone + ", Data de Nascimento: " + dataNascimento;
    }
}
